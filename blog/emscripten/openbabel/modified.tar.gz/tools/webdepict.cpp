#include <openbabel/mol.h>
#include <openbabel/obconversion.h>

extern "C"
{

  int SmilesToSVG(const char* smiles, int options, void* mbuf, unsigned int buflen)
  {
    OpenBabel::OBMol mol;
    OpenBabel::OBConversion conv;
    conv.SetInFormat("smi");

    bool ok = conv.ReadString(&mol, smiles);
    if (!ok) return -1;

    if (options==0) {
      conv.SetOutFormat("ascii");
      conv.AddOption("a", OpenBabel::OBConversion::OUTOPTIONS, "2.2");
    
    } else {
      conv.SetOutFormat("svg");
      conv.AddOption("C", OpenBabel::OBConversion::OUTOPTIONS);
      conv.AddOption("P", OpenBabel::OBConversion::OUTOPTIONS, "500");
    }

    std::string out = conv.WriteString(&mol);

    if (out.size()+1 >= buflen)
        return -1;

    char* dst = (char*)mbuf;
    strcpy(dst, out.c_str());
    return out.size();
  }
}


int  main()
{
  const char* smiles = "CC(=O)Cl";
  OpenBabel::OBMol mol;
  OpenBabel::OBConversion conv;
  conv.SetInFormat("smi");
  conv.SetOutFormat("ascii");

  bool ok = conv.ReadString(&mol, smiles);
  if (!ok) return 1;
  std::string out = conv.WriteString(&mol);
  printf("%s\n", out.c_str());

  return 0;
}

